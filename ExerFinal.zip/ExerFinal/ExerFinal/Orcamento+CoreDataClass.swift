//
//  Orcamento+CoreDataClass.swift
//  ExerFinal
//
//  Created by ALUNO on 25/10/16.
//  Copyright © 2016 IESB. All rights reserved.
//

import Foundation
import CoreData


public class Orcamento: NSManagedObject {

}
