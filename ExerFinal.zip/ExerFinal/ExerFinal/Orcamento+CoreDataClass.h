//
//  Orcamento+CoreDataClass.h
//  ExerFinal
//
//  Created by ALUNO on 25/10/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Orcamento : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Orcamento+CoreDataProperties.h"
