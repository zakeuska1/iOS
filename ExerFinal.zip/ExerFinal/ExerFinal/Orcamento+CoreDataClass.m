//
//  Orcamento+CoreDataClass.m
//  ExerFinal
//
//  Created by ALUNO on 25/10/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Orcamento+CoreDataClass.h"

@implementation Orcamento

@end
